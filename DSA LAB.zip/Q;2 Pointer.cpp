#include <iostream>
using namespace std;
int main () {
	
	
	int a=10,*p,**q;
	//int p=&q;
	//int q=&p;
	
	cout<<"print the address and values"<<endl<<endl;
	
	cout<<"print the value of A ................."<<a<<endl;//10
	cout<<"print the pointer p.................. "<<&a<<endl;//10
	cout<<"print the double pointer of q ....... "<<a<<endl;//2000
	cout<<"print the value of p....... "<<a<<endl;//1000
	cout<<"print the value of q........ "<<a<<endl;//2000
	
	
}
