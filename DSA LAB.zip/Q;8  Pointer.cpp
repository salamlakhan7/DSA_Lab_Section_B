#include <iostream>
using namespace std;
int main ()
{
	int a=4;
	int* p=&a;
	
	cout<<"   *p  = "<<*p<<endl;
	
	//new keyword 
	 p=new int(49);
	cout<<"  "<<*p<<endl;
	
	p=new int (50);
	delete p;         //this 50 value is now free , now random value accessed
	cout<<"deleted value = "<<*p<<endl;
	
	
}
