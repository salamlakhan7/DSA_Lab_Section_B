#include <iostream>
using namespace std;
int main () {
	
	
	
	int a=10;
	int *p=&a;
	
	cout<<"a = "<<a<<endl;
	
	a=20;
	cout<<"updation of A"<<endl<<a<<endl;
	
	return 0;
		
	
}
