#include <iostream>
using namespace std;
int main () {

int *p, *q;

p=new int ;

q=p;
*p=50;
*q=100;

cout<<"*p  =   "<<*p<<endl;
cout<<"*q  =   "<<*q<<endl;
	
	
	
	
	
	
	
	
}
