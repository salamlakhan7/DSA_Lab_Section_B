#include <iostream>
using namespace std;
int main () {
	
	int x=10;
	int *y=&x;
	
	cout<<"Print the values and addresses"<<endl;
	
	cout<<"the value of   x is .........."<<x<<endl;//10
	cout<<"the address of x is ........."<<&x<<endl;//1000
	cout<<"the value of   y  is  ........."<<y<<endl;//1000
	cout<<"the address of &y is........"<<y<<endl;//2000
	cout<<"the value of   y*  is........."<<*y<<endl;///10

	
	
	
	
	return  0;
	
}
