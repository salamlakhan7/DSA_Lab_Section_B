#include <iostream>
using namespace std;
int main () {
	
	
	int a=10;
	int *p;
	
	cout<<*p<<endl; //10
	
	int **q=&p; //2000
	
	
	cout<<*q<<"     "<<**q<<endl; //1000     1004
	                              //
	
	
	
}
