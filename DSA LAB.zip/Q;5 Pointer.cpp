#include <iostream>
using namespace std;
int main () {


int arr[]={10,20,30};
 int *p=arr;
cout<<*arr<<endl;

for (int i=0;i<3;i++)
{
	cout<<*p<<endl;
	p++;                 //array ++ moving values
}

	
}

