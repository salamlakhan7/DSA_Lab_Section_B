#include <iostream>
using namespace std ;
int main () {
	
	
	int *p ,*q;
	p=new int ;
	*p=70;
	
	q=p;
	*q=90;
	
	cout<<" the address of p        "<<p<<endl;
	cout<<" the address of q        "<<q<<endl;
	cout<<"point to the value of p  "<<*p<<endl;
	cout<<"point to the value of q  "<<*q<<endl;
	
	
	
	
	
	
	
	
	
}
